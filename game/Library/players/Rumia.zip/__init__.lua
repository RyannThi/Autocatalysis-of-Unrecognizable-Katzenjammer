Include'THlib\\player\\rumia\\rumia.lua'
AddPlayerToPlayerList('Rumia','rumia_player','Rumia')